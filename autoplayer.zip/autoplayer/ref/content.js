console.log('YouTube Video Sequencer: Loading...');

class YouTubeSequencer {
    constructor() {
        this.videoQueue = [];
        this.currentIndex = 0;
        this.autoPlay = true;
        this.isInitialized = false;
        this.videoEndListener = null;
        this.initialize();
    }

    async initialize() {
        console.log('Initializing YouTube Sequencer...');
        await this.loadSettings();
        this.setupPageListeners();
        this.injectControls();
        this.setupVideoEndListener();
        this.isInitialized = true;
    }

    async loadSettings() {
        return new Promise((resolve) => {
            chrome.storage.local.get(['videoQueue', 'currentIndex', 'autoPlay'], (result) => {
                console.log('Loaded settings:', result);
                if (result.videoQueue && Array.isArray(result.videoQueue)) {
                    this.videoQueue = result.videoQueue;
                }
                this.currentIndex = result.currentIndex || 0;
                this.autoPlay = result.autoPlay !== undefined ? result.autoPlay : true;
                resolve();
            });
        });
    }

    saveSettings() {
        chrome.storage.local.set({
            videoQueue: this.videoQueue,
            currentIndex: this.currentIndex,
            autoPlay: this.autoPlay
        }, () => {
            console.log('Settings saved:', {
                queueLength: this.videoQueue.length,
                currentIndex: this.currentIndex,
                autoPlay: this.autoPlay
            });
        });
    }

    setupPageListeners() {
        let lastUrl = window.location.href;
        
        const observer = new MutationObserver(() => {
            const currentUrl = window.location.href;
            if (currentUrl !== lastUrl) {
                console.log('URL changed:', currentUrl);
                lastUrl = currentUrl;
                
                setTimeout(() => {
                    this.handlePageChange();
                }, 500);
            }
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });

        this.handlePageChange();
    }

    handlePageChange() {
        const isVideoPage = window.location.pathname.includes('/watch');
        
        console.log('Page change detected. Video page:', isVideoPage);
        
        if (isVideoPage) {
            this.handleVideoPage();
        } else {
            this.handleNonVideoPage();
        }
    }

    handleVideoPage() {
        console.log('On video page, checking if in sequence...');
        
        const currentVideoId = this.getCurrentVideoId();
        console.log('Current video ID:', currentVideoId);
        
        if (!currentVideoId) {
            console.log('Could not get video ID');
            return;
        }
        
        const sequenceIndex = this.videoQueue.findIndex(video => video.id === currentVideoId);
        console.log('Found in sequence at index:', sequenceIndex);
        
        if (sequenceIndex !== -1) {
            this.currentIndex = sequenceIndex;
            this.saveSettings();
            console.log('Updated current index to:', this.currentIndex);
            
            this.setupVideoEndListener();
        }
        
        setTimeout(() => {
            this.injectControls();
        }, 1000);
    }

    handleNonVideoPage() {
        console.log('On non-video page (channel/home)');
        setTimeout(() => {
            this.injectControls();
        }, 1000);
    }

    setupVideoEndListener() {
        if (this.videoEndListener) {
            const video = document.querySelector('video');
            if (video) {
                video.removeEventListener('ended', this.videoEndListener);
            }
        }
        
        const checkInterval = setInterval(() => {
            const video = document.querySelector('video');
            if (video) {
                console.log('Video element found, setting up end listener');
                
                this.videoEndListener = () => {
                    console.log('Video ended! Auto-play:', this.autoPlay, 'Queue length:', this.videoQueue.length);
                    
                    if (this.autoPlay && this.videoQueue.length > 0) {
                        let nextIndex = this.currentIndex + 1;
                        if (nextIndex >= this.videoQueue.length) {
                            nextIndex = 0;
                        }
                        
                        console.log('Playing next video at index:', nextIndex);
                        
                        setTimeout(() => {
                            this.playVideoAtIndex(nextIndex);
                        }, 1000);
                    }
                };
                
                video.addEventListener('ended', this.videoEndListener);
                clearInterval(checkInterval);
            }
        }, 500);
        
        setTimeout(() => clearInterval(checkInterval), 5000);
    }

    playVideoAtIndex(index) {
        if (index >= 0 && index < this.videoQueue.length) {
            this.currentIndex = index;
            this.saveSettings();
            
            const video = this.videoQueue[index];
            console.log('Navigating to video:', video);
            
            window.location.href = video.url;
        }
    }

    injectControls() {
        this.removeExistingControls();
        
        const isVideoPage = window.location.pathname.includes('/watch');
        
        if (isVideoPage) {
            this.injectVideoControls();
        } else {
            this.injectChannelControls();
        }
    }

    removeExistingControls() {
        const existingControls = document.getElementById('youtube-sequencer-controls');
        if (existingControls) {
            existingControls.remove();
        }
        
        const existingModal = document.getElementById('sequence-modal');
        if (existingModal) {
            existingModal.remove();
        }
    }

    injectChannelControls() {
        console.log('Injecting channel controls...');
        
        const container = this.findChannelContainer();
        if (!container) {
            console.log('No container found, will retry');
            setTimeout(() => this.injectChannelControls(), 1000);
            return;
        }

        const currentVideoId = this.getCurrentVideoId();
        const isInSequence = this.videoQueue.some(video => video.id === currentVideoId);
        const currentIndex = isInSequence ? this.videoQueue.findIndex(v => v.id === currentVideoId) : -1;

        const controls = document.createElement('div');
        controls.id = 'youtube-sequencer-controls';
        controls.className = 'youtube-sequencer-controls';
        controls.innerHTML = `
            <div class="sequencer-header">
                <h3>🎬 YouTube Sequence Player</h3>
                <div class="header-buttons">
                    <button id="toggle-auto" class="btn ${this.autoPlay ? 'active' : ''}">
                        ${this.autoPlay ? '🔁 Auto' : '⏸️ Auto'}
                    </button>
                    <button id="clear-sequence" class="btn clear-btn">Clear</button>
                </div>
            </div>
            
            <div class="sequence-status">
                <div class="status-info">
                    <span class="status-label">Sequence:</span>
                    <span class="status-value">${this.videoQueue.length} videos</span>
                </div>
                ${this.videoQueue.length > 0 ? `
                <div class="status-info">
                    <span class="status-label">Current:</span>
                    <span class="status-value">${this.currentIndex + 1} of ${this.videoQueue.length}</span>
                </div>
                ` : ''}
            </div>
            
            <div class="sequence-controls">
                ${this.videoQueue.length > 0 ? `
                <button id="play-sequence" class="btn play-btn">
                    ▶ Play Sequence
                </button>
                <button id="play-next" class="btn small-btn" ${this.currentIndex >= this.videoQueue.length - 1 ? 'disabled' : ''}>
                    Next
                </button>
                ` : `
                <div class="empty-message">
                    No sequence yet. Select videos below and click "Add to Sequence".
                </div>
                `}
            </div>
            
            ${this.videoQueue.length > 0 ? `
            <div class="sequence-preview">
                <div class="preview-header">Your Sequence:</div>
                <div class="preview-list">
                    ${this.renderSequencePreview()}
                </div>
            </div>
            ` : ''}
            
            <div class="video-selection">
                <div class="selection-header">
                    <span>Select Videos:</span>
                    <div class="selection-buttons">
                        <button id="select-all" class="btn small-btn">Select All</button>
                        <button id="add-selected" class="btn add-btn small-btn">Add to Sequence</button>
                    </div>
                </div>
                <div class="selection-hint">
                    Click checkboxes on videos below, then click "Add to Sequence"
                </div>
            </div>
        `;

        container.insertBefore(controls, container.firstChild);
        this.attachChannelEventListeners();
        this.addCheckboxesToVideos();
    }

    injectVideoControls() {
        console.log('Injecting video controls...');
        
        const container = document.querySelector('#primary-inner') || 
                         document.querySelector('#primary') ||
                         document.querySelector('ytd-watch-flexy') ||
                         document.body;
        
        if (!container) {
            console.log('Video container not found');
            return;
        }

        const currentVideoId = this.getCurrentVideoId();
        const isInSequence = this.videoQueue.some(video => video.id === currentVideoId);
        const sequenceIndex = isInSequence ? this.videoQueue.findIndex(v => v.id === currentVideoId) : -1;
        
        const hasNextVideo = isInSequence && sequenceIndex < this.videoQueue.length - 1;
        const nextVideoIndex = hasNextVideo ? sequenceIndex + 1 : 0;
        const hasPrevVideo = isInSequence && sequenceIndex > 0;

        const controls = document.createElement('div');
        controls.id = 'youtube-sequencer-controls';
        controls.className = 'youtube-sequencer-controls video-controls';
        controls.innerHTML = `
            <div class="sequencer-header">
                <h3>🎬 YouTube Sequence Player</h3>
                <div class="header-buttons">
                    <button id="toggle-auto" class="btn ${this.autoPlay ? 'active' : ''}">
                        ${this.autoPlay ? '🔁 Auto ON' : '⏸️ Auto OFF'}
                    </button>
                    <button id="add-this-video" class="btn add-btn">+ Add This</button>
                </div>
            </div>
            
            <div class="video-progress">
                ${isInSequence ? `
                <div class="progress-info">
                    <div class="progress-text">
                        <span class="current-pos">Video ${sequenceIndex + 1} of ${this.videoQueue.length}</span>
                        <span class="remaining">(${this.videoQueue.length - sequenceIndex - 1} remaining)</span>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: ${((sequenceIndex + 1) / this.videoQueue.length) * 100}%"></div>
                    </div>
                </div>
                ` : `
                <div class="progress-text not-in-sequence">
                    This video is not in your sequence
                </div>
                `}
            </div>
            
            <div class="sequence-info">
                <div class="info-row">
                    <span class="info-label">Sequence Status:</span>
                    <span class="info-value">${isInSequence ? 'Playing' : 'Not in Sequence'}</span>
                </div>
                ${isInSequence ? `
                <div class="info-row">
                    <span class="info-label">Current Position:</span>
                    <span class="info-value">${sequenceIndex + 1} of ${this.videoQueue.length}</span>
                </div>
                ` : ''}
            </div>
            
            <div class="video-navigation">
                <button id="prev-video" class="btn nav-btn prev-btn" ${!hasPrevVideo ? 'disabled' : ''}>
                    <span class="nav-icon">◀</span>
                    <span class="nav-text">Previous</span>
                </button>
                
                <button id="skip-video" class="btn skip-btn" title="Skip to next video" ${!hasNextVideo ? 'disabled' : ''}>
                    <span class="skip-icon">⏭️</span>
                    <span class="skip-text">Skip</span>
                </button>
                
                <button id="next-video" class="btn nav-btn next-btn" ${!hasNextVideo ? 'disabled' : ''}>
                    <span class="nav-text">Next</span>
                    <span class="nav-icon">▶</span>
                </button>
            </div>
            
            ${hasNextVideo ? `
            <div class="next-preview">
                <div class="preview-header">Next Up:</div>
                <div class="preview-item">
                    <span class="preview-number">${nextVideoIndex + 1}.</span>
                    <span class="preview-title" title="${this.videoQueue[nextVideoIndex].title}">
                        ${this.truncateText(this.videoQueue[nextVideoIndex].title, 40)}
                    </span>
                    <button class="play-next-btn" data-index="${nextVideoIndex}" title="Play Now">
                        ▶
                    </button>
                </div>
            </div>
            ` : isInSequence ? `
            <div class="sequence-end">
                <div class="end-message">🎉 Last video in sequence!</div>
                <div class="end-buttons">
                    <button id="restart-sequence" class="btn restart-btn">Restart Sequence</button>
                    <button id="back-to-channel" class="btn channel-btn">Back to Channel</button>
                </div>
            </div>
            ` : ''}
            
            <div class="quick-actions">
                <button id="view-sequence" class="btn small-btn">📋 View All Videos</button>
                <button id="edit-sequence" class="btn small-btn edit-btn">✏️ Edit Sequence</button>
            </div>
            
            ${this.videoQueue.length > 0 ? `
            <div class="sequence-overview">
                <div class="overview-header">
                    <span>Sequence Overview</span>
                    <span class="overview-count">${this.videoQueue.length} videos</span>
                </div>
                <div class="overview-list">
                    ${this.renderSequenceOverview(sequenceIndex)}
                </div>
            </div>
            ` : ''}
        `;

        container.insertBefore(controls, container.firstChild);
        this.attachVideoEventListeners();
    }

    findChannelContainer() {
        const selectors = [
            '#contents',
            '#primary',
            '#page-manager',
            'ytd-browse'
        ];
        
        for (const selector of selectors) {
            const element = document.querySelector(selector);
            if (element) {
                return element;
            }
        }
        
        return document.body;
    }

    addCheckboxesToVideos() {
        setTimeout(() => {
            const videoElements = document.querySelectorAll('ytd-rich-grid-media, ytd-grid-video-renderer');
            console.log(`Found ${videoElements.length} video elements`);
            
            videoElements.forEach((element, index) => {
                if (element.querySelector('.seq-checkbox-container')) return;
                
                const link = element.querySelector('a#thumbnail, a#video-title-link');
                const titleElement = element.querySelector('#video-title');
                
                if (!link || !titleElement) return;
                
                const href = link.href;
                const videoId = this.extractVideoId(href);
                const title = titleElement.textContent.trim();
                
                if (!videoId) return;
                
                const isInSequence = this.videoQueue.some(video => video.id === videoId);
                
                const container = document.createElement('div');
                container.className = 'seq-checkbox-container';
                container.innerHTML = `
                    <input type="checkbox" 
                           class="seq-checkbox" 
                           id="seq-${videoId}"
                           data-video-id="${videoId}"
                           data-title="${title.replace(/"/g, '&quot;')}"
                           ${isInSequence ? 'checked' : ''}>
                    <label for="seq-${videoId}" class="seq-checkbox-label"></label>
                `;
                
                const thumbnail = element.querySelector('ytd-thumbnail, #thumbnail');
                if (thumbnail) {
                    thumbnail.style.position = 'relative';
                    thumbnail.appendChild(container);
                }
            });
            
            this.attachCheckboxListeners();
            
        }, 1500);
    }

    extractVideoId(url) {
        if (!url) return '';
        try {
            const urlObj = new URL(url);
            return urlObj.searchParams.get('v') || url.split('v=')[1]?.split('&')[0] || '';
        } catch (e) {
            return '';
        }
    }

    renderSequencePreview() {
        return this.videoQueue.map((video, index) => {
            const isCurrent = index === this.currentIndex;
            return `
                <div class="preview-item ${isCurrent ? 'current' : ''}" data-index="${index}">
                    <span class="preview-number">${index + 1}.</span>
                    <span class="preview-title" title="${video.title}">${this.truncateText(video.title, 30)}</span>
                    ${isCurrent ? '<span class="current-badge">▶</span>' : ''}
                    <button class="remove-btn" data-index="${index}" title="Remove">×</button>
                </div>
            `;
        }).join('');
    }

    renderSequenceOverview(currentIndex) {
        if (this.videoQueue.length === 0) {
            return '<div class="empty-overview">No videos in sequence</div>';
        }
        
        const start = Math.max(0, currentIndex - 2);
        const end = Math.min(this.videoQueue.length, currentIndex + 3);
        
        let html = '';
        
        for (let i = start; i < end; i++) {
            const video = this.videoQueue[i];
            const isCurrent = i === currentIndex;
            const isPlayed = i < currentIndex;
            
            html += `
                <div class="overview-item ${isCurrent ? 'current' : ''} ${isPlayed ? 'played' : ''}" data-index="${i}">
                    <span class="overview-number">${i + 1}.</span>
                    <span class="overview-title" title="${video.title}">
                        ${this.truncateText(video.title, 35)}
                    </span>
                    <div class="overview-actions">
                        ${isCurrent ? '<span class="now-playing">▶</span>' : ''}
                        ${!isCurrent ? `<button class="jump-to-btn small-btn" data-index="${i}">Jump</button>` : ''}
                    </div>
                </div>
            `;
        }
        
        if (this.videoQueue.length > 5) {
            html += `
                <div class="show-more">
                    <span>... and ${this.videoQueue.length - 5} more videos</span>
                    <button id="show-full-sequence" class="btn small-btn">Show All</button>
                </div>
            `;
        }
        
        return html;
    }

    attachChannelEventListeners() {
        document.getElementById('play-sequence')?.addEventListener('click', () => {
            if (this.videoQueue.length > 0) {
                this.playSequence();
            }
        });

        document.getElementById('play-next')?.addEventListener('click', () => {
            if (this.currentIndex < this.videoQueue.length - 1) {
                this.playVideoAtIndex(this.currentIndex + 1);
            }
        });

        document.getElementById('toggle-auto')?.addEventListener('click', () => {
            this.autoPlay = !this.autoPlay;
            this.saveSettings();
            this.updateAutoButton();
        });

        document.getElementById('clear-sequence')?.addEventListener('click', () => {
            if (confirm('Clear the entire sequence?')) {
                this.videoQueue = [];
                this.currentIndex = 0;
                this.saveSettings();
                this.injectControls();
            }
        });

        document.getElementById('select-all')?.addEventListener('click', () => {
            document.querySelectorAll('.seq-checkbox').forEach(cb => cb.checked = true);
        });

        document.getElementById('add-selected')?.addEventListener('click', () => {
            this.addSelectedVideos();
        });

        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('remove-btn')) {
                const index = parseInt(e.target.dataset.index);
                this.removeFromSequence(index);
            }
        });
    }

    attachVideoEventListeners() {
        document.getElementById('toggle-auto')?.addEventListener('click', () => {
            this.autoPlay = !this.autoPlay;
            this.saveSettings();
            this.updateAutoButton();
        });

        document.getElementById('add-this-video')?.addEventListener('click', () => {
            this.addCurrentVideo();
        });

        document.getElementById('prev-video')?.addEventListener('click', () => {
            this.playPreviousVideo();
        });

        document.getElementById('next-video')?.addEventListener('click', () => {
            this.playNextVideo();
        });

        document.getElementById('skip-video')?.addEventListener('click', () => {
            this.skipCurrentVideo();
        });

        document.getElementById('restart-sequence')?.addEventListener('click', () => {
            this.restartSequence();
        });

        document.getElementById('back-to-channel')?.addEventListener('click', () => {
            window.history.back();
        });

        document.getElementById('view-sequence')?.addEventListener('click', () => {
            this.showFullSequence();
        });

        document.getElementById('edit-sequence')?.addEventListener('click', () => {
            window.location.href = 'https://www.youtube.com';
        });

        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('play-next-btn')) {
                const index = parseInt(e.target.dataset.index);
                this.playVideoAtIndex(index);
            }
            
            if (e.target.classList.contains('jump-to-btn')) {
                const index = parseInt(e.target.dataset.index);
                this.playVideoAtIndex(index);
            }
            
            if (e.target.id === 'show-full-sequence') {
                this.showFullSequence();
            }
        });
    }

    attachCheckboxListeners() {
        document.addEventListener('change', (e) => {
            if (e.target.classList.contains('seq-checkbox')) {
                const label = e.target.nextElementSibling;
                if (e.target.checked) {
                    label.classList.add('checked');
                } else {
                    label.classList.remove('checked');
                }
            }
        });
    }

    addSelectedVideos() {
        const checkboxes = document.querySelectorAll('.seq-checkbox:checked');
        let added = 0;
        
        checkboxes.forEach(checkbox => {
            const videoId = checkbox.dataset.videoId;
            const title = checkbox.dataset.title;
            
            const exists = this.videoQueue.some(video => video.id === videoId);
            
            if (!exists) {
                this.videoQueue.push({
                    id: videoId,
                    title: title,
                    url: `https://www.youtube.com/watch?v=${videoId}`
                });
                added++;
            }
        });
        
        if (added > 0) {
            this.saveSettings();
            alert(`Added ${added} video${added === 1 ? '' : 's'} to sequence!`);
            this.injectControls();
        } else {
            alert('No new videos selected or all selected videos are already in sequence.');
        }
    }

    addCurrentVideo() {
        const videoId = this.getCurrentVideoId();
        const title = this.getCurrentVideoTitle();
        
        if (videoId && title) {
            const exists = this.videoQueue.some(video => video.id === videoId);
            
            if (!exists) {
                this.videoQueue.push({
                    id: videoId,
                    title: title,
                    url: window.location.href
                });
                this.saveSettings();
                alert(`"${this.truncateText(title, 50)}" added to sequence!`);
                this.injectControls();
            } else {
                alert('This video is already in your sequence!');
            }
        }
    }

    removeFromSequence(index) {
        if (index >= 0 && index < this.videoQueue.length) {
            this.videoQueue.splice(index, 1);
            
            if (this.currentIndex >= index) {
                this.currentIndex = Math.max(0, this.currentIndex - 1);
            }
            
            this.saveSettings();
            this.injectControls();
        }
    }

    playPreviousVideo() {
        const currentVideoId = this.getCurrentVideoId();
        const currentIndex = this.videoQueue.findIndex(v => v.id === currentVideoId);
        
        if (currentIndex > 0) {
            this.playVideoAtIndex(currentIndex - 1);
        } else if (currentIndex === 0) {
            alert('This is the first video in the sequence.');
        } else {
            alert('This video is not in your sequence.');
        }
    }

    playNextVideo() {
        const currentVideoId = this.getCurrentVideoId();
        const currentIndex = this.videoQueue.findIndex(v => v.id === currentVideoId);
        
        if (currentIndex !== -1 && currentIndex < this.videoQueue.length - 1) {
            this.playVideoAtIndex(currentIndex + 1);
        } else if (currentIndex === this.videoQueue.length - 1) {
            if (confirm('You\'ve reached the end of the sequence. Restart from the beginning?')) {
                this.restartSequence();
            }
        } else {
            alert('This video is not in your sequence.');
        }
    }

    skipCurrentVideo() {
        const currentVideoId = this.getCurrentVideoId();
        const currentIndex = this.videoQueue.findIndex(v => v.id === currentVideoId);
        
        if (currentIndex !== -1 && currentIndex < this.videoQueue.length - 1) {
            this.playVideoAtIndex(currentIndex + 1);
        } else if (currentIndex === this.videoQueue.length - 1) {
            this.restartSequence();
        } else {
            alert('This video is not in your sequence or no next video available.');
        }
    }

    restartSequence() {
        if (this.videoQueue.length > 0) {
            this.currentIndex = 0;
            this.saveSettings();
            this.playVideoAtIndex(0);
        }
    }

    showFullSequence() {
        const modal = document.createElement('div');
        modal.id = 'sequence-modal';
        modal.className = 'sequence-modal';
        modal.innerHTML = `
            <div class="modal-overlay"></div>
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Full Sequence (${this.videoQueue.length} videos)</h3>
                    <button class="close-modal">×</button>
                </div>
                <div class="modal-body">
                    <div class="sequence-list-full">
                        ${this.videoQueue.map((video, index) => {
                            const isCurrent = this.videoQueue[index].id === this.getCurrentVideoId();
                            return `
                                <div class="full-sequence-item ${isCurrent ? 'current' : ''}" data-index="${index}">
                                    <span class="full-number">${index + 1}.</span>
                                    <span class="full-title" title="${video.title}">${video.title}</span>
                                    <div class="full-actions">
                                        ${isCurrent ? '<span class="current-badge">Now Playing</span>' : ''}
                                        <button class="play-from-here btn small-btn" data-index="${index}">
                                            Play
                                        </button>
                                    </div>
                                </div>
                            `;
                        }).join('')}
                    </div>
                </div>
                <div class="modal-footer">
                    <button id="close-modal-btn" class="btn">Close</button>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        document.querySelector('.close-modal')?.addEventListener('click', () => {
            modal.remove();
        });
        
        document.querySelector('.modal-overlay')?.addEventListener('click', () => {
            modal.remove();
        });
        
        document.getElementById('close-modal-btn')?.addEventListener('click', () => {
            modal.remove();
        });
        
        document.querySelectorAll('.play-from-here').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const index = parseInt(e.target.dataset.index);
                modal.remove();
                this.playVideoAtIndex(index);
            });
        });
    }

    playSequence() {
        if (this.videoQueue.length === 0) {
            alert('No videos in sequence!');
            return;
        }
        
        console.log('Starting sequence from beginning');
        this.currentIndex = 0;
        this.saveSettings();
        
        const firstVideo = this.videoQueue[0];
        window.location.href = firstVideo.url;
    }

    getCurrentVideoId() {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get('v');
    }

    getCurrentVideoTitle() {
        const titleElement = document.querySelector('h1.title, yt-formatted-string.style-scope.ytd-watch-metadata');
        return titleElement ? titleElement.textContent.trim() : 'Unknown Video';
    }

    updateAutoButton() {
        const buttons = document.querySelectorAll('#toggle-auto');
        buttons.forEach(button => {
            button.className = `btn ${this.autoPlay ? 'active' : ''}`;
            button.textContent = this.autoPlay ? '🔁 Auto ON' : '⏸️ Auto OFF';
        });
    }

    truncateText(text, maxLength) {
        if (!text) return '';
        return text.length > maxLength ? text.substring(0, maxLength) + '...' : text;
    }
}

let sequencer = null;

function init() {
    sequencer = new YouTubeSequencer();
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}